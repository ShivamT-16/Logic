var classstack =
[
    [ "stack", "classstack.html#acd90ca289a90d074a7597503e876d3ae", null ],
    [ "isEmpty", "classstack.html#adc343daa5cd8aaab473af868ab44302b", null ],
    [ "isFull", "classstack.html#a81e440f7bf1aef3847255be5aa437f5a", null ],
    [ "peek", "classstack.html#abfcb9e3f669367ea87ac080902e839f8", null ],
    [ "pop", "classstack.html#afd6bf8357a2139cb5c2e03253d9caf96", null ],
    [ "push", "classstack.html#a43f88528b679dbd3468adf44e96490f6", null ],
    [ "arr", "classstack.html#a6687b2fde43600e5361126cc915721d5", null ],
    [ "size", "classstack.html#a926a597bae913d1bf4772be35c14b71e", null ],
    [ "top", "classstack.html#a2d100511cad42e140cbbe2863cab8c8c", null ]
];