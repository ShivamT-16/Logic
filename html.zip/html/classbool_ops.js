var classbool_ops =
[
    [ "eval", "classbool_ops.html#a10f264ef2bb90184f710e43071209315", null ],
    [ "eval", "classbool_ops.html#a4f0402e89a7772568b7465e87a53dd3c", null ],
    [ "evaluate", "classbool_ops.html#a9b4a7a6a5c999b936a49466a05a0469b", null ],
    [ "index", "classbool_ops.html#a32908bd5a22d712f48509d0ffacd6ba0", null ],
    [ "inside", "classbool_ops.html#acaa86a33865db3705e0ccf7d4ffb02fd", null ],
    [ "is_operator", "classbool_ops.html#a915493c162c1496a67a91782cf4cb7fa", null ],
    [ "order", "classbool_ops.html#afeb84457a614eb6ad54a356a0fde1d00", null ]
];