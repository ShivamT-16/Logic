var searchData=
[
  ['truthvalue_54',['truthValue',['../classnode.html#a4424551846b4af76b82e37da0b168fef',1,'node']]]
];
