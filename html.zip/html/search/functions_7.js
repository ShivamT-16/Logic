var searchData=
[
  ['stack_49',['stack',['../classstack.html#acd90ca289a90d074a7597503e876d3ae',1,'stack']]]
];
