var searchData=
[
  ['top_54',['top',['../classstack.html#a2d100511cad42e140cbbe2863cab8c8c',1,'stack']]],
  ['truthvalue_55',['truthValue',['../classnode.html#a4424551846b4af76b82e37da0b168fef',1,'node']]]
];
