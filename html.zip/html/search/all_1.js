var searchData=
[
  ['boolops_1',['boolOps',['../classbool_ops.html',1,'']]]
];
