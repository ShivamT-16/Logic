var searchData=
[
  ['boolops_27',['boolOps',['../classbool_ops.html',1,'']]]
];
