var searchData=
[
  ['stack_21',['stack',['../classstack.html',1,'stack'],['../classstack.html#acd90ca289a90d074a7597503e876d3ae',1,'stack::stack()']]],
  ['strops_22',['strOps',['../classstr_ops.html',1,'']]]
];
