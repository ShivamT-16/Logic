var searchData=
[
  ['eval_32',['eval',['../classbool_ops.html#a10f264ef2bb90184f710e43071209315',1,'boolOps::eval(char op, bool b1)'],['../classbool_ops.html#a4f0402e89a7772568b7465e87a53dd3c',1,'boolOps::eval(char op, bool b1, bool b2)']]],
  ['evaluate_33',['evaluate',['../classbool_ops.html#a9b4a7a6a5c999b936a49466a05a0469b',1,'boolOps']]]
];
