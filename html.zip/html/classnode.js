var classnode =
[
    [ "node", "classnode.html#aa5703ad1183fe4be1f1c064cb9794243", null ],
    [ "atom", "classnode.html#a8cf5881e142d79fc6bea930bab1180ef", null ],
    [ "left", "classnode.html#a7cbff55ff448f557223f79299056e9b1", null ],
    [ "right", "classnode.html#abdc86d4c8604c481752953af3235fc47", null ],
    [ "truthValue", "classnode.html#a4424551846b4af76b82e37da0b168fef", null ]
];